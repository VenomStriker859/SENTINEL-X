#include "image_receiver.h"
#include "config.h"
#include "crc16.h"
#include "serial_protocol.h"
#include "image_debug.h"
#include "audio_debug.h"

#include <Arduino.h>
#include <string.h>


void ImageReceiver::begin(LoRaManager *lora){

    loraRef = lora;

    sessionActive = false;
    receivedCount = 0;
    totalPackets = 0;
    currentMessageID = 0;
    currentPacketType = IMAGE_PACKET;
    lastChunkLength = MAX_PAYLOAD_SIZE;
    lastCompletedMessageID = 65535;
    lastPacketTime = 0;
    ackSentForGap = false;

    memset(
        packetReceived,
        0,
        sizeof(packetReceived)
    );
}

void ImageReceiver::startNewSession(uint16_t messageID, uint16_t total){
    currentMessageID = messageID;
    totalPackets = total;
    receivedCount = 0;
    sessionActive = true;
    ackSentForGap = false;
    memset(
        packetReceived,
        0,
        sizeof(packetReceived)
    );
    Serial.print("New data session, messageID=");
    Serial.print(messageID);
    Serial.print(", totalPackets=");
    Serial.println(total);
}


void ImageReceiver::handleIncoming(
    uint8_t *buffer,
    size_t len
){

    if (len != sizeof(ImagePacket)){
        return;
    }


    ImagePacket *pkt =
        (ImagePacket*)buffer;


    // ==========================================
    // CRC CHECK
    // ==========================================

    uint16_t crcCheck =
        CRC16::calculate(
            (uint8_t*)&pkt->header,
            sizeof(PacketHeader)
        );

    crcCheck ^=
        CRC16::calculate(
            pkt->payload,
            pkt->header.payloadLength
        );


    if (crcCheck != pkt->crc){

        Serial.println(
            "Discarding packet: CRC mismatch"
        );

        return;
    }


    // ==========================================
    // NEW SESSION
    // ==========================================

    if (
    !sessionActive ||
    pkt->header.messageID != currentMessageID
){

    startNewSession(
        pkt->header.messageID,
        pkt->header.totalPackets
    );

    currentPacketType =
        pkt->header.type;
}


    lastPacketTime = millis();
    ackSentForGap = false;


    // ==========================================
    // PACKET NUMBER CHECK
    // ==========================================

    if (
        pkt->header.packetNumber >= totalPackets ||
        pkt->header.packetNumber >= MAX_PACKETS
    ){

        Serial.println(
            "Discarding packet: index out of range"
        );

        return;
    }


    // ==========================================
    // STORE PACKET
    // ==========================================

    if (!packetReceived[pkt->header.packetNumber]){

        memcpy(

            imageBuffer +
            (
                (uint32_t)pkt->header.packetNumber *
                MAX_PAYLOAD_SIZE
            ),

            pkt->payload,

            pkt->header.payloadLength
        );


        packetReceived[
            pkt->header.packetNumber
        ] = true;


        receivedCount++;


        if (
            pkt->header.packetNumber ==
            totalPackets - 1
        ){

            lastChunkLength =
                pkt->header.payloadLength;
        }


        Serial.print("Packet ");
        Serial.print(
            pkt->header.packetNumber + 1
        );

        Serial.print("/");
        Serial.print(totalPackets);

        Serial.println(" received.");
    }


    // ==========================================
    // COMPLETE MESSAGE
    // ==========================================

    if (receivedCount == totalPackets){

        // Always send ACK so the sender knows
        // that the message was received.
        sendAck(true);

        // Check whether this message was already
        // completely received and processed.
        if (currentMessageID != lastCompletedMessageID){

            finalizeImage();

            lastCompletedMessageID =
                currentMessageID;
        }
        else{

            Serial.println(
                "[RECEIVER] Duplicate completed message ignored."
            );
        }

        sessionActive = false;
    }
}


void ImageReceiver::update(){

    if (
        sessionActive &&
        receivedCount < totalPackets
    ){

        if (
            !ackSentForGap &&
            (
                millis() - lastPacketTime >
                BATCH_GAP_MS
            )
        ){

            Serial.println(
                "Batch gap detected -- sending ACK with missing packet bitmap."
            );

            sendAck(false);

            ackSentForGap = true;
        }


        if (
            millis() - lastPacketTime >
            IMAGE_SESSION_TIMEOUT_MS
        ){

            Serial.print(
                "Image session TIMED OUT. messageID="
            );

            Serial.print(currentMessageID);

            Serial.print(", received ");

            Serial.print(receivedCount);

            Serial.print("/");

            Serial.print(totalPackets);

            Serial.println(
                " packets. Message discarded."
            );

            sessionActive = false;
        }
    }
}


void ImageReceiver::sendAck(bool success){

    ImageAckPacket ack;

    ack.type = ACK_PACKET;

    ack.messageID =
        currentMessageID;

    ack.totalPackets =
        totalPackets;


    memset(
        ack.missingBitmap,
        0,
        sizeof(ack.missingBitmap)
    );


    if (!success){

        for (
            uint16_t i = 0;
            i < totalPackets &&
            i < MAX_PACKETS;
            i++
        ){

            if (!packetReceived[i]){

                ack.missingBitmap[i / 8] |=
                    (1 << (i % 8));
            }
        }
    }


    ack.crc =
        CRC16::calculate(
            (uint8_t*)&ack,
            sizeof(ImageAckPacket) -
            sizeof(uint16_t)
        );


    loraRef->send(
        (uint8_t*)&ack,
        sizeof(ImageAckPacket)
    );


    Serial.println(
        success
        ? "ACK sent: message complete."
        : "ACK sent: missing packets reported."
    );
}


void ImageReceiver::finalizeImage(){

    uint32_t totalBytes =
        (uint32_t)(
            totalPackets - 1
        ) *
        MAX_PAYLOAD_SIZE +
        lastChunkLength;


    // =================================================
    // AUDIO
    // =================================================

    if (
        currentPacketType ==
        AUDIO_PACKET
    ){

        Serial.println();

        Serial.println(
            "================================"
        );

        Serial.println(
            " AUDIO RECEIVED"
        );

        Serial.println(
            "================================"
        );

        Serial.print(
            "Message ID: "
        );

        Serial.println(
            currentMessageID
        );

        Serial.print(
            "Audio size: "
        );

        Serial.print(
            totalBytes
        );

        Serial.println(
            " bytes"
        );


        // Send complete audio to laptop
        printAudioOverSerial(
            imageBuffer,
            totalBytes
        );


        Serial.println(
            "Audio sent to laptop."
        );

        Serial.println(
            "================================"
        );

        Serial.println();
    }


    // =================================================
    // TEXT
    // =================================================

    else if (
        currentPacketType ==
        TEXT_PACKET
    ){

        String text = "";


        for (
            uint32_t i = 0;
            i < totalBytes;
            i++
        ){

            text +=
                (char)imageBuffer[i];
        }


        Serial.println();

        Serial.println(
            "================================"
        );

        Serial.println(
            " TEXT MESSAGE RECEIVED"
        );

        Serial.println(
            "================================"
        );


        Serial.print(
            "Message ID: "
        );

        Serial.println(
            currentMessageID
        );


        Serial.print(
            "Message: "
        );

        Serial.println(
            text
        );


        Serial.println(
            "================================"
        );

        Serial.println();


        sendTextJson(
            currentMessageID,
            text
        );
    }


    // =================================================
    // IMAGE
    // =================================================

    else if (
        currentPacketType ==
        IMAGE_PACKET
    ){

        Serial.println();

        Serial.println(
            "================================"
        );

        Serial.println(
            " IMAGE REASSEMBLED"
        );

        Serial.println(
            "================================"
        );


        Serial.print(
            "Message ID: "
        );

        Serial.println(
            currentMessageID
        );


        Serial.print(
            "Image size: "
        );

        Serial.print(
            totalBytes
        );

        Serial.println(
            " bytes"
        );


        // Send reconstructed JPEG to laptop
        printImageOverSerial(
            imageBuffer,
            totalBytes
        );


        Serial.println(
            "Received image sent to laptop."
        );


        sendImageJson(
            currentMessageID,
            imageBuffer,
            totalBytes
        );
    }


    // =================================================
    // GPS
    // =================================================

    else if (
        currentPacketType ==
        GPS_PACKET
    ){

        Serial.println(
            "GPS packet received."
        );
    }


    else {

        Serial.println(
            "Unknown packet type received."
        );
    }
    sessionActive = false;
}