#include "serial_protocol.h"
#include <Arduino.h>
#include "mbedtls/base64.h"

void sendImageJson(uint16_t messageId, const uint8_t *buf, size_t len){
    size_t requiredLen = 0;
    mbedtls_base64_encode(nullptr, 0, &requiredLen, buf, len);

    uint8_t *encodedBuf = (uint8_t*)malloc(requiredLen + 1);
    if (!encodedBuf){
        Serial.println("Failed to allocate base64 buffer for JSON image output");
        return;
    }

    size_t encodedLen = 0;
    mbedtls_base64_encode(encodedBuf, requiredLen, &encodedLen, buf, len);
    encodedBuf[encodedLen] = '\0';

    Serial.print("{\"type\":\"image\",\"nodeId\":");
    Serial.print(NODE_ID);
    Serial.print(",\"messageId\":");
    Serial.print(messageId);
    Serial.print(",\"bytes\":");
    Serial.print(len);
    Serial.print(",\"timestamp\":");
    Serial.print(millis());
    Serial.print(",\"data\":\"");
    Serial.print((char*)encodedBuf);
    Serial.println("\"}");

    free(encodedBuf);
}

void sendTextJson(uint16_t messageId, const String &text){
    Serial.print("{\"type\":\"text\",\"nodeId\":");
    Serial.print(NODE_ID);
    Serial.print(",\"messageId\":");
    Serial.print(messageId);
    Serial.print(",\"timestamp\":");
    Serial.print(millis());
    Serial.print(",\"message\":\"");
    // Escape double-quotes in the text so it doesn't break the JSON string
    for (size_t i = 0; i < text.length(); i++){
        char c = text[i];
        if (c == '"' || c == '\\'){
            Serial.print('\\');
        }
        Serial.print(c);
    }
    Serial.println("\"}");
}

void sendGpsJson(uint16_t messageId, float lat, float lon){
    Serial.print("{\"type\":\"gps\",\"nodeId\":");
    Serial.print(NODE_ID);
    Serial.print(",\"messageId\":");
    Serial.print(messageId);
    Serial.print(",\"timestamp\":");
    Serial.print(millis());
    Serial.print(",\"lat\":");
    Serial.print(lat, 6);
    Serial.print(",\"lon\":");
    Serial.print(lon, 6);
    Serial.println("}");
}