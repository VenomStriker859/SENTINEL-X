#pragma once
#include <stddef.h>
#include "protocol.h"
#include "lora_manager.h"

class ImageReceiver {
public:
    void begin(LoRaManager *lora);
    void handleIncoming(uint8_t *buffer, size_t len);
    void update();

private:
    LoRaManager *loraRef;
    static const uint16_t MAX_PACKETS = MAX_IMAGE_PACKETS;
    uint8_t  imageBuffer[MAX_PACKETS * MAX_PAYLOAD_SIZE];
    bool     packetReceived[MAX_PACKETS];
    uint16_t totalPackets;
    uint16_t receivedCount;
    uint16_t currentMessageID;
    uint16_t lastChunkLength;
    uint8_t currentPacketType;
    uint16_t lastCompletedMessageID;
    bool     sessionActive;
    bool     ackSentForGap;
    unsigned long lastPacketTime;

    void startNewSession(uint16_t messageID, uint16_t total);
    void finalizeImage();
    void sendAck(bool success);
};