#pragma once

#define LORA_SCK   12
#define LORA_MISO  13
#define LORA_MOSI  11
#define LORA_SS    10
#define LORA_RST   9
#define LORA_DIO0  8

#define LORA_FREQUENCY 433E6

#define STATUS_LED 14
#define BLINK_DURATION 150

#define TEXT_MESSAGE_ID_OFFSET 10000
#define GPS_MESSAGE_ID_OFFSET  20000

#define BATCH_GAP_MS 300              // silence this long mid-transfer = sender paused, send current ACK
#define IMAGE_SESSION_TIMEOUT_MS 8000 // silence this long = give up on the session entirely (bumped up to safely exceed the sender's full retry cycle)