#pragma once
#include <stdint.h>
#include <stddef.h>
#include <Arduino.h>

#define NODE_ID 1

void sendImageJson(uint16_t messageId, const uint8_t *buf, size_t len);
void sendTextJson(uint16_t messageId, const String &text);
void sendGpsJson(uint16_t messageId, float lat, float lon);