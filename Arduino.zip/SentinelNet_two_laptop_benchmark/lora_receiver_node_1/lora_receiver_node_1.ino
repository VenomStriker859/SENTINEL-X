#include <SPI.h>
#include <LoRa.h>

#include "config.h"
#include "lora_manager.h"
#include "image_receiver.h"
#include "image_debug.h"

LoRaManager loraManager;
ImageReceiver imageReceiver;
bool ledOn = false;
unsigned long ledOnTime = 0;


void setup(){
    Serial.begin(115200);
    delay(1000);

    pinMode(STATUS_LED, OUTPUT);
    digitalWrite(STATUS_LED, LOW);

    Serial.println();
    Serial.println("================================");
    Serial.println(" SentinelNet ESP32-S3 Receiver");
    Serial.println("================================");

    SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);

    if (!loraManager.begin(LORA_FREQUENCY, LORA_SS, LORA_RST, LORA_DIO0)){
        Serial.println("LoRa init FAILED. Halting.");
        while (true){ delay(1000); }
    }

    imageReceiver.begin(&loraManager);
    loraManager.startReceive();
    Serial.println("LoRa initialization SUCCESS!");
    Serial.println("Waiting for image packets...");
    Serial.println();
}


void loop(){
    if (loraManager.available()){
        uint8_t buffer[LORA_MAX_PACKET_SIZE];
        size_t len = loraManager.readPacket(buffer);

        if (len > 0){
            digitalWrite(STATUS_LED, HIGH);
            ledOn = true;
            ledOnTime = millis();

            imageReceiver.handleIncoming(buffer, len);

            Serial.print("RSSI: ");
            Serial.print(loraManager.getLastRssi());
            Serial.print(" dBm | SNR: ");
            Serial.print(loraManager.getLastSnr());
            Serial.println(" dB");
        }
    }
    imageReceiver.update();   // NEW -- checks for a stalled session every loop iteration
    if (ledOn && (millis() - ledOnTime >= BLINK_DURATION)){
        digitalWrite(STATUS_LED, LOW);
        ledOn = false;
    }
}