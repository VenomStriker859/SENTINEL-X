import base64
import binascii
import json
import os
import struct
import threading
import time
import wave
import serial
from serial import SerialException

SENDER_PORT = "COM10"   # ESP32-S3 camera + LoRa sender
RECEIVER_PORT = "COM11" # LoRa receiver ESP32
BAUD_RATE = 115200
OUTPUT_DIR = os.path.join(os.path.expanduser("~"), "SentinelNet")
IMAGE_DIR = os.path.join(OUTPUT_DIR, "received_images")
SENT_DIR = os.path.join(OUTPUT_DIR, "sent_images")
AUDIO_DIR = os.path.join(OUTPUT_DIR, "received_audio")
SENT_AUDIO_DIR = os.path.join(OUTPUT_DIR, "sent_audio")
for _d in (IMAGE_DIR, SENT_DIR, AUDIO_DIR, SENT_AUDIO_DIR):
    os.makedirs(_d, exist_ok=True)

stop_event = threading.Event()


# ---------------------------------------------------------------- helpers
def next_index(folder, prefix):
    """Next free number, so restarting the script never overwrites older files."""
    existing = [n for n in os.listdir(folder) if n.startswith(prefix + "_")]
    return len(existing) + 1


def save_jpeg(folder, prefix, index, jpeg):
    path = os.path.join(folder, f"{prefix}_{index:03d}_{time.strftime('%H%M%S')}.jpg")
    with open(path, "wb") as f:
        f.write(jpeg)
    return path


# IMA ADPCM decoder (matches the encoder on the sender: 4-bit codes, low nibble first).
_INDEX = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8]
_STEP = [
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45,
    50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230,
    253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963,
    1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327,
    3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442,
    11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
    32767,
]


def adpcm_message_to_wav(data, folder, prefix, index):
    """data = 'ADP1' + uint16 rate + uint32 sample count + 4-bit ADPCM. Returns (path, seconds)."""
    if len(data) < 10 or data[:4] != b"ADP1":
        raise ValueError("not an ADP1 audio message")
    rate, count = struct.unpack("<HI", data[4:10])
    payload = data[10:]
    count = min(count, len(payload) * 2)
    pred, idx = 0, 0
    pcm = bytearray()
    for n in range(count):
        byte = payload[n >> 1]
        code = (byte >> 4) if (n & 1) else (byte & 0x0F)
        step = _STEP[idx]
        diff = step >> 3
        if code & 4:
            diff += step
        if code & 2:
            diff += step >> 1
        if code & 1:
            diff += step >> 2
        pred += -diff if code & 8 else diff
        pred = max(-32768, min(32767, pred))
        idx = max(0, min(88, idx + _INDEX[code]))
        pcm += struct.pack("<h", pred)
    path = os.path.join(folder, f"{prefix}_{index:03d}_{time.strftime('%H%M%S')}.wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(bytes(pcm))
    return path, count / rate


def adpcm_encode_message(samples, rate):
    """int16 samples -> 'ADP1' + uint16 rate + uint32 count + 4-bit IMA ADPCM (low nibble first)."""
    pred, idx = 0, 0
    out = bytearray(b"ADP1" + struct.pack("<HI", rate, len(samples)))
    out += bytes((len(samples) + 1) // 2)
    for n, sample in enumerate(samples):
        step = _STEP[idx]
        diff = int(sample) - pred
        code = 0
        if diff < 0:
            code = 8
            diff = -diff
        vpdiff = step >> 3
        if diff >= step:
            code |= 4
            diff -= step
            vpdiff += step
        step >>= 1
        if diff >= step:
            code |= 2
            diff -= step
            vpdiff += step
        step >>= 1
        if diff >= step:
            code |= 1
            vpdiff += step
        pred += -vpdiff if code & 8 else vpdiff
        pred = max(-32768, min(32767, pred))
        idx = max(0, min(88, idx + _INDEX[code]))
        pos = 10 + (n >> 1)
        out[pos] = (out[pos] | (code << 4)) if (n & 1) else code
    return bytes(out)


AUDIO_RATE = 8000


def record_laptop_mic(seconds):
    """Record from the default laptop microphone. Returns int16 numpy array at 8 kHz, mono."""
    try:
        import numpy as np
        import sounddevice as sd
    except ImportError as exc:
        raise RuntimeError("Audio needs: pip install sounddevice numpy") from exc
    audio, rate, last_error = None, None, None
    for r in (16000, 48000, 44100):          # rates most laptop microphones accept
        try:
            audio = sd.rec(int(seconds * r), samplerate=r, channels=1, dtype="int16")
            sd.wait()
            rate = r
            break
        except Exception as exc:              # try the next rate
            last_error = exc
    if audio is None:
        raise RuntimeError(f"Could not record from the laptop microphone: {last_error}")
    x = audio[:, 0].astype(np.float32)
    if rate != AUDIO_RATE:
        k = max(1, int(round(rate / AUDIO_RATE)))
        if k > 1:
            x = np.convolve(x, np.ones(k, dtype=np.float32) / k, mode="same")   # crude anti-alias
        n_out = int(len(x) * AUDIO_RATE / rate)
        x = np.interp(np.arange(n_out) * (rate / AUDIO_RATE), np.arange(len(x)), x)
    peak = float(np.max(np.abs(x))) if len(x) else 0.0
    if peak > 0:
        x = x * min(8.0, 29000.0 / peak)      # raise quiet recordings (up to 8x)
    return np.clip(x, -32768, 32767).astype(np.int16)


def save_wav(folder, prefix, index, samples, rate):
    path = os.path.join(folder, f"{prefix}_{index:03d}_{time.strftime('%H%M%S')}.wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(samples.tobytes())
    return path


# ---------------------------------------------------------------- receiver side
def receiver_listener():
    image_counter = next_index(IMAGE_DIR, "received") - 1
    audio_counter = next_index(AUDIO_DIR, "received") - 1
    skipping_image_block = False
    audio_lines = None            # list while an AUDIO_START ... AUDIO_END block is arriving
    while not stop_event.is_set():
        try:
            with serial.Serial(RECEIVER_PORT, BAUD_RATE, timeout=1) as ser:
                print(f"[RECEIVER] Connected to {RECEIVER_PORT}")
                time.sleep(2)  # allow ESP32 USB serial to reset
                while not stop_event.is_set():
                    raw = ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("utf-8", errors="replace").strip()

                    # --- audio block
                    if line == "AUDIO_START":
                        audio_lines = []
                        continue
                    if line == "AUDIO_END" and audio_lines is not None:
                        try:
                            data = base64.b64decode("".join(audio_lines), validate=True)
                            audio_counter += 1
                            path, secs = adpcm_message_to_wav(data, AUDIO_DIR, "received", audio_counter)
                            print(f"[RECEIVER] AUDIO SAVED: {path} ({secs:.1f} s)")
                        except Exception as exc:
                            print(f"[RECEIVER][AUDIO ERROR] {exc}")
                        audio_lines = None
                        continue
                    if audio_lines is not None:
                        audio_lines.append(line)
                        continue

                    # --- image: the receiver prints each image twice (IMG_START block and a
                    # JSON line). We save only the JSON line and skip the block.
                    if line == "IMG_START":
                        skipping_image_block = True
                    elif line == "IMG_END":
                        skipping_image_block = False
                    elif skipping_image_block:
                        continue
                    elif line.startswith('{"type":"image"'):
                        try:
                            obj = json.loads(line)
                            jpeg = base64.b64decode(obj["data"], validate=True)
                            if not (jpeg.startswith(b"\xff\xd8") and jpeg.endswith(b"\xff\xd9")):
                                raise ValueError("received bytes do not look like a complete JPEG")
                            image_counter += 1
                            filename = save_jpeg(IMAGE_DIR, "received", image_counter, jpeg)
                            print(f"[RECEIVER] IMAGE SAVED: {filename} ({len(jpeg)} bytes)")
                        except Exception as exc:
                            print(f"[RECEIVER][IMAGE ERROR] {exc}")
                    elif line:
                        print(line)
        except (SerialException, OSError) as exc:
            if not stop_event.is_set():
                print(f"[RECEIVER] Could not open {RECEIVER_PORT}: {exc}. Retrying in 2 seconds...")
                time.sleep(2)


# ---------------------------------------------------------------- sender side
audio_ready = threading.Event()   # set when the sender answers AUDIO_READY


def sender_listener(ser):
    """Print what the sender board prints and save the copy of each captured photo it dumps."""
    sent_image_counter = next_index(SENT_DIR, "sent") - 1
    collecting = False
    lines = []
    while not stop_event.is_set():
        try:
            raw = ser.readline()
        except (SerialException, OSError):
            return
        if not raw:
            continue
        line = raw.decode("utf-8", errors="replace").strip()
        if line == "AUDIO_READY":
            audio_ready.set()
        elif line == "IMG_START":
            collecting = True
            lines = []
        elif line == "IMG_END" and collecting:
            collecting = False
            try:
                jpeg = base64.b64decode("".join(lines), validate=True)
                if not (jpeg.startswith(b"\xff\xd8") and jpeg.endswith(b"\xff\xd9")):
                    raise ValueError("sent image does not look like a complete JPEG")
                sent_image_counter += 1
                path = save_jpeg(SENT_DIR, "sent", sent_image_counter, jpeg)
                print(f"[SENDER] SENT IMAGE SAVED: {path} ({len(jpeg)} bytes)")
            except Exception as exc:
                print(f"[SENDER][IMAGE ERROR] {exc}")
        elif collecting:
            lines.append(line)
        elif line:
            print("[SENDER] " + line)


def main():
    print("\n========================================")
    print(" SentinelNet — ESP32 Camera + Audio + LoRa")
    print(" Laptop webcam is NOT used.")
    print(f" Sent images:      {SENT_DIR}")
    print(f" Received images:  {IMAGE_DIR}")
    print(f" Sent audio:       {SENT_AUDIO_DIR}")
    print(f" Received audio:   {AUDIO_DIR}")
    print("========================================")

    threading.Thread(target=receiver_listener, daemon=True).start()
    sender = None
    try:
        while sender is None:
            try:
                sender = serial.Serial(SENDER_PORT, BAUD_RATE, timeout=1, write_timeout=5)
                time.sleep(2)  # allow ESP32 reset after serial open
                print(f"[SENDER] Connected to {SENDER_PORT}")
                threading.Thread(target=sender_listener, args=(sender,), daemon=True).start()
            except (SerialException, OSError) as exc:
                print(f"[SENDER] Could not open {SENDER_PORT}: {exc}")
                input("Close Arduino Serial Monitor, check COM port, then press Enter to retry...")

        while True:
            print("\n[T] Send text + capture image from ESP32 camera")
            print("[A] Record audio from the laptop microphone and send it")
            print("[X] Send text only (radio test)")
            print("[Q] Quit")
            choice = input("Select: ").strip().lower()
            if choice == "q":
                break
            if choice == "t":
                message = input("Text to associate with the image: ").strip()
                if not message:
                    print("Message cannot be empty.")
                    continue
                sender.write(("TEXT:" + message + "\n").encode("utf-8"))
                sender.flush()
                time.sleep(0.25)
                sender.write(b"CAPTURE\n")
                sender.flush()
                print("[CONTROL] Requested ESP32 camera capture. Watch the serial logs for camera/LoRa status.")
            elif choice == "a":
                secs = input("Seconds to record from the laptop microphone (1-6, Enter = 5): ").strip()
                secs = int(secs) if secs.isdigit() and 1 <= int(secs) <= 6 else 5
                try:
                    print(f"[AUDIO] Recording {secs} s from the laptop microphone... speak now.")
                    samples = record_laptop_mic(secs)
                except Exception as exc:
                    print(f"[AUDIO][ERROR] {exc}")
                    continue
                sent_audio_counter = next_index(SENT_AUDIO_DIR, "sent")
                path = save_wav(SENT_AUDIO_DIR, "sent", sent_audio_counter, samples, AUDIO_RATE)
                print(f"[AUDIO] SENT AUDIO SAVED: {path}")
                message = adpcm_encode_message(samples.tolist(), AUDIO_RATE)
                crc = binascii.crc_hqx(message, 0xFFFF)
                audio_ready.clear()
                sender.write(f"AUDIO_BIN:{len(message)}:{crc}\n".encode("utf-8"))
                sender.flush()
                if not audio_ready.wait(5):
                    print("[AUDIO][ERROR] Sender did not answer. Is the new sender sketch uploaded?")
                    continue
                sender.write(message)
                sender.flush()
                print(f"[CONTROL] Sent {len(message)} bytes of audio to the sender. "
                      "LoRa transfer takes ~20 s; wait for [RECEIVER] AUDIO SAVED.")
            elif choice == "x":
                message = input("Text message: ").strip()
                if message:
                    sender.write(("TEST_TEXT:" + message + "\n").encode("utf-8"))
                    sender.flush()
                    print("[CONTROL] Text-only test sent.")
            else:
                print("Unknown option.")
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        stop_event.set()
        if sender is not None:
            sender.close()


if __name__ == "__main__":
    main()
